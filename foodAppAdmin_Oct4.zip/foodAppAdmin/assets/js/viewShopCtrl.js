var app = angular.module('myApp', []);
app.controller('addShopCtrl', function($scope, $http) {
	var getShopsUrl = "http://localhost:8080/foodAppServer/index.php/shop/getshops";
    $http.get(getShopsUrl).then(function(rawResponse) {
        $scope.response = rawResponse.data;
    });
});