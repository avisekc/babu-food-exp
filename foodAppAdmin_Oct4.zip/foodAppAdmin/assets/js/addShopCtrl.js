var app = angular.module('myApp', []);
app.controller('addShopCtrl', function($scope, $http) {
	$scope.shopObj = {
			// "shop_id": "0",
			"shop_name": "",
			"shop_address": "",
			"shop_phone1": "",
			"shop_phone2": "",
			"is_active": ""
		}
	
	$scope.addShop = function () {	
		var addShopsUrl = "http://localhost:8080/foodAppServer/index.php/shop/addshop";
		$http.post(addShopsUrl, $scope.shopObj).then(function(rawResponse) {
			$scope.response = rawResponse.data;
		});
	}
});