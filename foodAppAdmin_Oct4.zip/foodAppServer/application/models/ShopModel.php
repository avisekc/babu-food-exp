<?php
class ShopModel extends CI_Model {

    public function __construct() {
        // $this->load does not exist until after you call this
        parent::__construct(); // Construct CI's core so that you can use it
        $this->load->database();
    }
    
    function getShops() {
        $data = [];
        //$q = $this->db->get('shop');
        $query = $this->db->query("SELECT * FROM shop");
        if($query->num_rows() > 0){
            foreach ($query->result() as $row){
                $data[] = $row;
            }
        }
        return $data;
    }
	
	
	function addShop($reqObj) {
        $sql = "INSERT INTO shop (shop_id, shop_name, shop_address, shop_phone1, shop_phone2, is_active) 
			VALUES ('', '".$reqObj->shop_name."', '".$reqObj->shop_address."', '".$reqObj->shop_phone1."', '', '')";
        // echo $sql; exit;
		$query = $this->db->query($sql);
        //print_r($query); exit;
        return $query;
    }
}