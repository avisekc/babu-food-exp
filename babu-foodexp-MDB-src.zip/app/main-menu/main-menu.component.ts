import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main-menu',
  templateUrl: './main-menu.component.html',
  styleUrls: ['./main-menu.component.css']
})
export class MainMenuComponent implements OnInit {

  public menuItems: any = [
    {
      "name": "Benerages",
      "url": "assets/images/menu-beverages.jpg",
      "caption": "Tea, Coffee, Cold drinks, Mineral Water & many more.."
    },
    {
      "name": "Lunch",
      "url": "assets/images/Indian-Thali.jpg",
      "caption": "Chicken Meal, Biriyani, Veg Thali & many more.."
    },
    {
      "name": "Fruits",
      "url": "assets/images/fruits-menu.jpg",
      "caption": "Banana, Apple & more.."
    }
  ];

  constructor(private router: Router) { }

  ngOnInit() {
  }

  selectMenu(menu: string) {
    this.router.navigateByUrl('/item-selection/'+menu);
  }

}
