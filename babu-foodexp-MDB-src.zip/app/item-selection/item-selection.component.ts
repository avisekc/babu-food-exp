import { Component, OnInit } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-item-selection',
  templateUrl: './item-selection.component.html',
  styleUrls: ['./item-selection.component.css']
})
export class ItemSelectionComponent implements OnInit {
  
  public menuItem: string = "";
  public menuItemList: any = [
    {
      "url": "assets/images/hyderabadi-chicken-biryani-1.jpg",
      "name": "Biriyani - chicken",
      "caption": "Popular throughout the Indian subcontinent",
      "price": "200",
      "currency": "Rs.",
      "pricePer": "per plate"
    },
    {
      "url": "assets/images/mutton-biryani-2.jpg",
      "name": "Biriyani - mutton",
      "caption": "Popular throughout the Indian subcontinent",
      "price": "250",
      "currency": "Rs.",
      "pricePer": "per plate"
    },
    {
      "url": "assets/images/veg-thali-1.jpg",
      "name": "Veg thali",
      "caption": "Popular throughout the Indian subcontinent",
      "price": "150",
      "currency": "Rs.",
      "pricePer": "per plate"
    }
  ];

  constructor(private route: ActivatedRoute) {
    this.route.params.subscribe( params => {
      console.log(params);
      this.menuItem = params['menuId'];
    });
  }

  ngOnInit() {
  }

}
