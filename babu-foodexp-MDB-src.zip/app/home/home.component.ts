import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  title = 'Babu-Food-Express';
  parentPage = "HOME";
  cardForm: FormGroup;

  constructor(private router: Router, private fb: FormBuilder) {
    this.cardForm = fb.group({
      materialFormCardEmailEx: ['', [Validators.email, Validators.required]],
      materialFormCardPasswordEx: ['', Validators.required]
    });
  }

  ngOnInit() {
  }

  submitLogin() {
    this.router.navigateByUrl('/main-menu');
  }
}
