import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-item-select-card',
  templateUrl: './item-select-card.component.html',
  styleUrls: ['./item-select-card.component.css']
})
export class ItemSelectCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
