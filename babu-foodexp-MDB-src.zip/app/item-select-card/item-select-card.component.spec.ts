import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemSelectCardComponent } from './item-select-card.component';

describe('ItemSelectCardComponent', () => {
  let component: ItemSelectCardComponent;
  let fixture: ComponentFixture<ItemSelectCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemSelectCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemSelectCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
