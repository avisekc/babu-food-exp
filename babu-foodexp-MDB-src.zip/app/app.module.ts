import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { MDBBootstrapModule } from 'angular-bootstrap-md';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { RegistrationComponent } from './registration/registration.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { ItemSelectionComponent } from './item-selection/item-selection.component';
import { ItemSelectCardComponent } from './item-select-card/item-select-card.component';
import { HeaderComponent } from './header/header.component';
import { SubHeaderComponent } from './sub-header/sub-header.component';

const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },
  // { path: 'registration',      component: RegistrationComponent },
  { path: 'main-menu',      component: MainMenuComponent },
  {
    path: 'item-selection/:menuId',
    component: ItemSelectionComponent
  },
  { path: '',
    redirectTo: '/home',
    pathMatch: 'full'
  }, 
  // { path: '**', component: PageNotFoundComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    MainMenuComponent,
    SubHeaderComponent,
    ItemSelectionComponent,
    /* RegistrationComponent,
    ,
    ,
    ItemSelectCardComponent,
     */
  ],
  imports: [
    BrowserModule,
    MDBBootstrapModule.forRoot(),
    FormsModule, ReactiveFormsModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
